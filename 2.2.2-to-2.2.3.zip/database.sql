UPDATE `tbl_settings` SET `message` = '2.2.3' WHERE `tbl_settings`.`type` = 'system_version';
INSERT INTO tbl_settings (`type`, `message`) SELECT * FROM (SELECT 'gmail_login', 1) AS tmp WHERE NOT EXISTS (SELECT type FROM tbl_settings WHERE type  ='gmail_login') LIMIT 1;
INSERT INTO tbl_settings (`type`, `message`) SELECT * FROM (SELECT 'email_login', 1) AS tmp WHERE NOT EXISTS (SELECT type FROM tbl_settings WHERE type  ='email_login') LIMIT 1;
INSERT INTO tbl_settings (`type`, `message`) SELECT * FROM (SELECT 'phone_login', 1) AS tmp WHERE NOT EXISTS (SELECT type FROM tbl_settings WHERE type  ='phone_login') LIMIT 1;
INSERT INTO tbl_settings (`type`, `message`) SELECT * FROM (SELECT 'apple_login', 1) AS tmp WHERE NOT EXISTS (SELECT type FROM tbl_settings WHERE type  ='apple_login') LIMIT 1;
